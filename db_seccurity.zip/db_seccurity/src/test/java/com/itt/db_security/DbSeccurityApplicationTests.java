package com.itt.db_security;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DbSeccurityApplicationTests {

	@Test
	void contextLoads() {
	}

}
