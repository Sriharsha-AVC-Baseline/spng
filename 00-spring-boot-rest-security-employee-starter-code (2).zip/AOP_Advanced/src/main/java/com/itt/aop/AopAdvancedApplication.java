package com.itt.aop;

import com.itt.aop.dao.StudentDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class AopAdvancedApplication {

	@Autowired
	StudentDao dao;

	public static void main(String[] args) {
		SpringApplication.run(AopAdvancedApplication.class, args);

	}

	@Bean
	public CommandLineRunner runner(StudentDao dao)
	{
		return runner -> {
			getNames(dao);
		};
	}

	public static int getNames(StudentDao dao)
	{
		dao.getStudentNames(1,"Hello",12.0).forEach(e-> System.out.println(e));
		return 0;
	}

}
