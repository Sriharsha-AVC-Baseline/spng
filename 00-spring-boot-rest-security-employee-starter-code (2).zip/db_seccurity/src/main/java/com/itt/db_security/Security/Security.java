package com.itt.db_security.Security;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.provisioning.JdbcUserDetailsManager;
import org.springframework.security.provisioning.UserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;

import javax.sql.DataSource;

@Configuration
public class Security {

/*    @Bean
    public UserDetailsManager userDetailsManager(DataSource source) {
        JdbcUserDetailsManager jdbcUserDetailsManager = new JdbcUserDetailsManager(source);

        jdbcUserDetailsManager.setUsersByUsernameQuery("SELECT USER_NAME,USER_PASSWORD,ENABLED FROM USERS WHERE USER_NAME=?");

        jdbcUserDetailsManager.setAuthoritiesByUsernameQuery("SELECT USER_NAME,USER_ROLE FROM authority WHERE USER_NAME=?");

        return jdbcUserDetailsManager;
    }*/


/*
    @Bean
    public UserDetailsService databaseUserDetails(DataSource source)
    {
        return new JdbcUserDetailsManager(source);
    }

*/

    @Bean
    public InMemoryUserDetailsManager userDetailsManagerSource()
    {
        UserDetails user = User.builder().username("AVC").password("{noop}123").roles("MANAGER").build();


        UserDetails user2 = User.builder().username("HEVC").password("{noop}1235").roles("LEAD").build();


        return new InMemoryUserDetailsManager(user,user2);
    }


    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity security) throws Exception
    {
        security.authorizeHttpRequests(configurer->configurer
                .requestMatchers("/manager/**").hasRole("MANAGER")
                .requestMatchers("/lead/**").hasRole("LEAD")
                .requestMatchers("/employee/**").hasRole("EXECUTIVE")
                .anyRequest().authenticated()
        ).formLogin(form->form.loginPage("/login").loginProcessingUrl("/loginSubmit").permitAll());

        security.csrf(csrf->csrf.disable());

        return security.build();
    }

}
