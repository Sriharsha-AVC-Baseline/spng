package com.itt.database_security.controller;

import com.itt.database_security.Entity.UserEntity;
import com.itt.database_security.dao.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.User;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class Home {

    @Autowired
    UserRepository userRepository;

    @RequestMapping("/")
    public String menu()
    {
        return "Main Menu";
    }

    @RequestMapping(path = "/register", method = RequestMethod.POST)
    public List<UserEntity> registerUser(@RequestBody UserEntity user)
    {
        userRepository.save(user);

        return userRepository.findByUserName(user.userName);
    }

}
