package com.itt.rest.controller;

import com.itt.rest.ExceptionMessage;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;

@ControllerAdvice
public class ExceptionHandler {

    @org.springframework.web.bind.annotation.ExceptionHandler
    public ResponseEntity<ExceptionMessage> sendException(RuntimeException exception)
    {
        ExceptionMessage exceptionMessage = new ExceptionMessage();
        exceptionMessage.setMessage(exception.getMessage());
        exceptionMessage.setStatus(HttpStatus.BAD_REQUEST.value());

        return new ResponseEntity<>(exceptionMessage,HttpStatus.BAD_REQUEST);
    }
}
