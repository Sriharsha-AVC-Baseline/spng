package com.itt.aop;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.context.annotation.Bean;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class AspectMethod {

    @Before("execution(public void getStatement())")
    @Order(1)
    public void printBefore()
    {
        System.out.println("Before");
    }

    @Before("execution(* com.itt.aop.*.*(..))")
    @Order(2)
    public void wildCard()
    {
        System.out.println("Wild card");
    }

}
