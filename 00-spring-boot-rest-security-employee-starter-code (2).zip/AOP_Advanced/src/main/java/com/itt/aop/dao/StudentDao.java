package com.itt.aop.dao;

import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class StudentDao {

    public static List<String> studentNames;

    StudentDao()
    {
        studentNames = new ArrayList<>();
        studentNames.add("Pavan");
        studentNames.add("Mohan");
        studentNames.add("Naveen");
        studentNames.add("Suresh");
    }
    public List<String> getStudentNames(int roll,String name,double marks)
    {
        return studentNames;
    }

}
