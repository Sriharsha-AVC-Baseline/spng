package com.itt.database_security;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DatabaseSecurityApplication {

	public static void main(String[] args) {
		SpringApplication.run(DatabaseSecurityApplication.class, args);
	}

}
