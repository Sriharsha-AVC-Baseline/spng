package com.itt.db_security.controller;


import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class HomeController {

    @RequestMapping("/")
    public String home()
    {
        return "home";
    }

    @RequestMapping("/manager")
    @ResponseBody
    public String manager()
    {
        return "Manager";
    }


    @RequestMapping("/employee")
    @ResponseBody
    public String employee()
    {
        return "Employee";
    }

    @RequestMapping("/lead")
    @ResponseBody
    public String lead()
    {
        return "Lead";
    }

    @RequestMapping("/login")
    public String login(){ return "login"; }

    @RequestMapping("/menu")
    public String menu() {return "main menu";}

    @RequestMapping("/secret")
    public String secret() { return "secret";}
}
