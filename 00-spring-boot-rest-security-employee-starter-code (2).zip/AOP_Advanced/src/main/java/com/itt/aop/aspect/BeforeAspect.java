package com.itt.aop.aspect;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.Signature;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.boot.autoconfigure.neo4j.Neo4jProperties;
import org.springframework.security.config.annotation.web.configurers.DefaultLoginPageConfigurer;
import org.springframework.security.web.authentication.ui.DefaultLoginPageGeneratingFilter;
import org.springframework.stereotype.Component;
import org.springframework.security.web.access.intercept.*;



@Aspect
@Component
public class BeforeAspect {

   // AuthorizationFilter


    @AfterReturning( pointcut = "com.itt.aop.aspect.PointcutClass.alterNames()",returning = "returnValue")
    public void printDetails(JoinPoint point)
    {
        System.out.println("After Aspect ");
        Object[] arguments = point.getArgs();
        Signature signature = point.getSignature();

        for(Object object:arguments)
        {
            System.out.println(object);
        }
        DefaultLoginPageGeneratingFilter
       // System.out.println(signature.toString());

    }

}
