package com.itt.aop;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

@Configuration
public class Simple {

    @Bean
    public DummyObject getDummyObject()
    {
        return new DummyObject();
    }

    @Bean
    public PassClass getPassClass()
    {
        return new PassClass();
    }
}
