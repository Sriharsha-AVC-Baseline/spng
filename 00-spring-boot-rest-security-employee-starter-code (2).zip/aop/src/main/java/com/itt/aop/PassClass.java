package com.itt.aop;

import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

@Component
public class PassClass {


    public void getStatement()
    {
        System.out.println("Hello People");
    }

}
