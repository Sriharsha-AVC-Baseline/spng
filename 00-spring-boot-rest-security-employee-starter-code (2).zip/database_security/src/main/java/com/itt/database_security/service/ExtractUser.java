package com.itt.database_security.service;

import com.itt.database_security.Entity.UserEntity;
import com.itt.database_security.dao.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class ExtractUser implements UserDetailsService {

    @Autowired
    UserRepository repository;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {

        List<UserEntity> entity = repository.findByUserName(username);

        if (entity.isEmpty()) {
            return null;
        } else {
            String password = entity.get(0).getPassword();
            String name = username;
            int enabled = entity.get(0).getEnabled();

            ArrayList authorities = new ArrayList();
            authorities.add(new SimpleGrantedAuthority("MANAGER"));
            User user = new User(name, password, authorities);

            return user;

        }
    }
}