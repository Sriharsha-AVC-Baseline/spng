package com.itt.database_security.dao;

import com.itt.database_security.Entity.UserEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface UserRepository extends JpaRepository<UserEntity,String> {

    public List<UserEntity> findByUserName(String userName);
}
