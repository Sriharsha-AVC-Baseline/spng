package com.itt.rest.controller;

import com.itt.rest.DAO.StudentDao;
import org.springframework.beans.factory.annotation.Autowire;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;


import com.itt.rest.Entity.Student;
import java.util.*;
@RestController
public class HomeController {

    @Autowired
    StudentDao studentDao;

    @GetMapping("/student")
    public List<Student> getStudents() {
        List<Student> students = studentDao.findAll();
        return students;
    }

    @GetMapping("/student/{id}")
    public Student getStudentById(@PathVariable("id") String id) {
        long count = studentDao.count();

        try {

            if (Long.valueOf(id) > count || Long.valueOf(id) < 0) {
                throw new RuntimeException("Student Not Found");
            }
            Integer studentId = Integer.valueOf(id);
            Optional<Student> student = studentDao.findById(studentId);
            return student.get();
        } catch (RuntimeException runtimeException) {
            throw new RuntimeException("Invalid Parameter");

        }


    }

    @PostMapping("/student")
    public Student insertStudent(@RequestBody Student student) {
        studentDao.save(student);
        return student;
    }

    @PutMapping("/student")
    public Student updateStudent(@RequestBody Student student) {
        studentDao.save(student);
        return student;
    }

    @DeleteMapping("/student/{id}")
    public void deleteStudentById(@PathVariable("id") String id) {
        long count = studentDao.count();

        try {

            if (Long.valueOf(id) > count || Long.valueOf(id) < 0) {
                throw new RuntimeException("Student Not Found");
            }
            Integer studentId = Integer.valueOf(id);
            studentDao.deleteById(studentId);
        }
         catch (RuntimeException runtimeException) {
            throw new RuntimeException("Invalid Parameter");

        }


    }


}
