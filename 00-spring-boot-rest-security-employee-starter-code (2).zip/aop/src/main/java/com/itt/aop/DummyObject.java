package com.itt.aop;

import org.springframework.stereotype.Component;

@Component
public class DummyObject {

    public void getStatement()
    {
        System.out.println("This is a Statement");
    }
}
