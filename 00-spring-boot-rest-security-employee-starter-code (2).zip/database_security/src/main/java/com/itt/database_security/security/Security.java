package com.itt.database_security.security;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
public class Security{


    @Bean
    public SecurityFilterChain filterRequest(HttpSecurity http) throws Exception
    {
        http.authorizeHttpRequests(configurer->configurer
                .requestMatchers("/").authenticated()
                .requestMatchers("/register").permitAll());

        http.csrf().disable();
        return http.build();
    }

}
